<?php

Route::group(['middleware' => 'cors'], function(){

	// Employee
	Route::group(['prefix' => 'employee'], function(){
		Route::get('/', 'EmployeeController@index');
		Route::post('/store', 'EmployeeController@store');
		Route::post('/update', 'EmployeeController@update');
		Route::get('/destroy/{id}', 'EmployeeController@destroy');
	});

	// Cart
	Route::group(['prefix' => 'cart'], function(){
		Route::get('/', 'CartController@index');
		Route::post('/store', 'CartController@store');
		Route::post('/update', 'CartController@update');
		Route::get('/destroy/{id}', 'CartController@destroy');
	});
	// Item
	Route::group(['prefix' => 'item'], function(){
		Route::get('/', 'ItemController@index');
	});

});
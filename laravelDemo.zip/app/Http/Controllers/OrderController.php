<?php

namespace App\Http\Controllers;

use App\Order;
use App\Order_item;
use App\Customer;
use Illuminate\Http\Request;
use DB;
use Response;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try 
        {
           /* $orders = Order::with(['customer' => function ($query) {
                                $query->select('name');
                            }])
                            ->select('order_no', 'payment_method','grand_total')
                            ->get();*/
            $orders = DB::table('orders')
                       ->join('customers', 'customers.id', '=', 'orders.customer_id')
                       ->select('order_no', 'payment_method','grand_total','name')
                       ->get();

            if(count($orders) > 0)
            {
                return Response::json(['data'=>$orders, 'status_code'=> 200], 200);
            }
            else
            {
                
                return Response::json(['status_code'=> 404, 'error' => 'Record Not found'], 404);
            }
            
        } 
        catch (Exception $e)
        {
            return Response::json(['status_code'=> 500, 'error' => 'There is something wrong'], 500);
        }
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try 
        {
            Order::create([
                'order_no' => $request->order_no,
                'payment_method' => $request->payment_method,
                'grand_total' => $request->grand_total,
                'customer_id' => $request->customer_id,
            ]);

            $order_id = DB::getPdo()->lastInsertId();
            foreach ($request->OrderItem as $key => $value) 
            {
                Order_item::create([
                    'order_id' => $order_id,
                    'item_id' => $value['item_id'],
                    'qty' => $value['qty'],
                ]);
            }
            
            return Response::json(['data'=>'Successfully Inserted', 'status_code'=> 201], 201);
        } 
        catch (Exception $e)
        {
            return Response::json(['status_code'=> 500, 'error' => 'There is something wrong'], 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(Order $order)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        //
    }
}

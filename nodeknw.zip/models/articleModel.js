let mongoose = require('mongoose');

let articleSchema = mongoose.Schema({
    title:{
        type: String,
        required: true
    },
    auther:{
        type: String,
        required: true
    },
    description:{
        type: String,
        required: true
    }
});

let Article = module.exports = mongoose.model('Article', articleSchema);
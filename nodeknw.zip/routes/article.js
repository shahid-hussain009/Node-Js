const express = require('express');
const router = express.Router();
// call Model
let Article = require('../models/articleModel');
let User = require('../models/userModel');

//add article
router.get('/add', ensureAuthenticated, (req, res) => {
    res.render('create', {
        title: 'Article'
    })
});

//get single article

router.get('/:id', (req, res) => {
    Article.findById(req.params.id, (err, article) =>{
        User.findById(article.auther, (err, user) => {
            res.render('single-article', {
                title: 'Single Aritcle',
                article:article,
                auther: user.name
            });
        })
        
    });
});


// Post article
router.post('/add', (req, res) => {
    req.checkBody('title', 'Title is required').notEmpty();
    //req.checkBody('auther', 'Auther is required').notEmpty();
    req.checkBody('description', 'Description is required').notEmpty();

    // Validation error
    let errors = req.validationErrors();
    if(errors)
    {
        res.render('create', {
            title: 'Article',
            errors:errors
        })
    }
    else
    {
        let article = new Article();
        article.title = req.body.title;
        article.auther = req.user._id;
        article.description = req.body.description;
        article.save((err) =>{
            if(err)
            {
                console.log('err');
                return;
            }
            else
            {
                req.flash('success', 'Successfully Created Article');
                res.redirect('/');
            }
        });
    }
});

//Edit article

router.get('/edit/:id', ensureAuthenticated, (req, res) => {
    Article.findById(req.params.id, (err, article) =>{
        if(article.auther != req.user._id)
        {
            req.flash('danger', 'You are not Athuraized');
            res.redirect('/');
        }
        res.render('edit-article', {
            title: 'Edit Aritcle',
            article:article
        });
    });
});

// update article
router.post('/update/:id', (req, res) => {
    let article = {};
    article.title = req.body.title;
    article.auther = req.body.auther;
    article.description = req.body.description;

    let query = {_id:req.params.id};

    Article.updateOne(query, article, (err) =>{
        if(err)
        {
            console.log('err');
            return;
        }
        else
        {
            req.flash('success', 'Article Updated Successfully');
            res.redirect('/');
        }
    });
});

//Delete article

router.delete('/delete/:id', (req, res) => {
    if(!req.user._id)
    {
        res.status(500).send();
    }
    let query = {_id:req.params.id};
    Article.findById(req.params.id, (err, article) => {
        if(article.auther != req.user._id)
        {
            res.status(500).send();
        }
        else
        {
            Article.remove(query, (err) => {
                if(err)
                {
                    console.log(err);
                }
                res.send('success');
            });
        }
    })
});


function ensureAuthenticated(req, res ,next)
{
    if(req.isAuthenticated())
    {
        return next();
    }
    else
    {
        req.flash('danger', 'Access Deny please login to view');
        res.redirect('/users/login');
    }
}

module.exports = router;
export class Item {
    id: number;
    item_name: string;
    price: number;
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

interface customertDetails{
  data:any;
  status_code: string
}

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) { }


    getCustomerList()
    {
        return this.http.get<customertDetails>(environment.apiUrl+'/customer').toPromise();
    }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


interface itemListDetails{
    data:any;
    status_code: string
}

@Injectable({
  providedIn: 'root'
})


export class ItemService {

  constructor(private http: HttpClient) { }

  getItemList(){
    return this.http.get<itemListDetails>(environment.apiUrl+'/item').toPromise();
  }
}

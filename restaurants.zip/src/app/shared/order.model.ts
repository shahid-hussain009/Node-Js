export class Order {
    id: Number;
    order_no: String;
    payment_method: String;
    grand_total: Number;
    customer_id: Number;
}

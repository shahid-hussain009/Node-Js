export class OrderItem {
    id: null;
    order_id: number;
    item_id: number;
    qty: number;
    item_name: string;
    price: number;
    total: number
}

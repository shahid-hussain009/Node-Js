import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { OrderItem } from 'src/app/shared/order-item.model';
import { ItemService } from 'src/app/shared/item.service';
import { Item } from 'src/app/shared/item.model';
import { NgForm } from '@angular/forms';
import { OrderService } from 'src/app/shared/order.service';


@Component({
  selector: 'app-order-items',
  templateUrl: './order-items.component.html',
  styleUrls: ['./order-items.component.css']
})
export class OrderItemsComponent implements OnInit {

  formData:OrderItem;
  itemList : Item[];
  isValid:boolean = true;

  constructor(@Inject(MAT_DIALOG_DATA) 
            public data, 
            public dialogRef:MatDialogRef<OrderItemsComponent>,
            private itemService: ItemService, 
            private orderService: OrderService) {  }

    ngOnInit() 
    {
        this.itemService.getItemList().then(res => this.itemList = res.data);
        if(this.data.orderItemIndex == null)
        {
            this.formData = 
            {
                id : null,
                order_id: this.data.id,
                item_id: 0,
                item_name: '',
                price: 0,
                qty: 0,
                total: 0
            }
        }
        else
        {
            this.formData = Object.assign({}, this.orderService.orderItems[this.data.orderItemIndex]);
            console.log(this.formData)
        }
    }

  // Update Price
    updatePrice(ctrl)
    {
        if(ctrl.selectedIndex == 0)
        {
            this.formData.price = 0;
            this.formData.item_name = '';
        }
        else
        {
            this.formData.price = this.itemList[ctrl.selectedIndex-1].price;
            this.formData.item_name = this.itemList[ctrl.selectedIndex-1].item_name;
        }
        this.updateTotal();
    }
    // Update Price
    updateTotal()
    {
        this.formData.total = parseFloat((this.formData.price * this.formData.qty).toFixed(2));
    }
    //submit data
    onSubmitItem(form:NgForm)
    {
        if(this.validateForm(form.value))
        {
            if(this.data.orderItemIndex == null)
            {
                this.orderService.orderItems.push(form.value);
            }
            else
            {
                this.orderService.orderItems[this.data.orderItemIndex] = form.value;
            }
            this.dialogRef.close();
        }
        
    }
    // validate 
    validateForm(formData: OrderItem)
    {
        this.isValid = true;
        if(formData.id == 0)
        {
            this.isValid = false;
        }
        else if(formData.qty == 0)
        {
            this.isValid = false;
        }
        return this.isValid;
    }

}
